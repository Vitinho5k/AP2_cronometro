package com.example.testdd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
